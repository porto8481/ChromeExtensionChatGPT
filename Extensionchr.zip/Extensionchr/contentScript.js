// Importamos las bibliotecas necesarias
import { BrowserExtension, contentScript } from 'chrome-extension-types';

// Creamos una extensión de navegador
export default class ChatGPTWarningExtension extends BrowserExtension {
  // Se ejecuta cuando la extensión se instala
  static install() {
    // Agregamos un script de contenido que se ejecutará en todas las páginas web
    contentScript({
      // Se ejecutará cuando se cargue la página web
      matches: ['*://chat.openai.com//*'],
      // Se ejecutará antes de que se cargue el contenido de la página web
      run: async (contentScriptHost) => {
        // Mostramos una advertencia
        contentScriptHost.showWarning('Esta página no es segura,el uso de informacion confidencial está totalmente desaconsejado..');
      },
    });
  }
}